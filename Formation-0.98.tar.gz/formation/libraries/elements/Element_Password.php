<?php defined('SYSPATH') or die('No direct script access.');

class Element_Password_Core extends Element_Input {

	protected $attr = array
	(
		'type'  => 'password',
		'class'=>'password'	

	);

} // End Form Password